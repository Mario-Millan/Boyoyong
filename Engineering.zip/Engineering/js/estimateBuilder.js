/**
 * Estimate Builder Main Application
 * Manages the creation and manipulation of detailed estimate forms
 */

import { calculateTotal, formatCurrency } from "./utils/calculation.js";
import { exportToExcel } from "./utils/excelExporter.js";
import { saveEstimate, loadEstimate } from "./utils/storage.js";

class EstimateBuilder {
  constructor() {
    this.itemCounter = 1;
    this.data = {
      projectInfo: {},
      items: [],
      exportSettings: {},
    };

    this.init();
  }

  init() {
    this.setupEventListeners();
    this.loadSampleData();
  }

  setupEventListeners() {
    // Header buttons
    document
      .getElementById("newEstimate")
      .addEventListener("click", () => this.newEstimate());
    document
      .getElementById("saveEstimate")
      .addEventListener("click", () => this.saveToLocalStorage());
    document
      .getElementById("loadEstimate")
      .addEventListener("click", () => this.loadFromLocalStorage());
    document
      .getElementById("exportExcel")
      .addEventListener("click", () => this.exportToExcel());

    // Add new item button
    document
      .getElementById("addNewItem")
      .addEventListener("click", () => this.addNewItem());

    // Project info inputs
    ["projectTitle", "location", "physicalTarget"].forEach((id) => {
      document.getElementById(id).addEventListener("input", (e) => {
        this.updateProjectInfo(id, e.target.value);
      });
    });

    // Export settings
    ["columnWidthScale", "rowHeightScale", "fontSize"].forEach((id) => {
      document.getElementById(id).addEventListener("change", (e) => {
        this.updateExportSettings(id, e.target.value);
      });
    });

    // Setup existing item
    this.setupItemEventListeners(1);
  }

  setupItemEventListeners(itemNumber) {
    const itemBlock = document
      .querySelector(`[data-item="${itemNumber}"]`)
      ?.closest(".item-block");
    if (!itemBlock) return;

    // --- SYNC TITLES WITH SUMMARY LABELS ---
    const titlesToSync = [
      { input: ".materials-title", label: ".summary-materials-label" },
      { input: ".equipment-title", label: ".summary-equipment-label" },
      { input: ".labor-title", label: ".summary-labor-label" },
    ];

    titlesToSync.forEach(({ input, label }) => {
      const inputEl = itemBlock.querySelector(input);
      const labelEl = itemBlock.querySelector(label);

      if (inputEl && labelEl) {
        inputEl.addEventListener("input", (e) => {
          const cleanName =
            e.target.value.replace(/^[A-Z]\.\s*/, "") || "Custom Item";
          labelEl.textContent = cleanName + ":";
        });
      }
    });

    itemBlock.querySelectorAll(".btn-add-row").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        const table = e.target.closest("table");
        this.addTableRow(table, itemNumber);
      });
    });

    const removeBtn = itemBlock.querySelector(".btn-remove-item");
    if (removeBtn) {
      removeBtn.addEventListener("click", () => {
        if (confirm("Are you sure you want to remove this item?")) {
          itemBlock.remove();
          this.updateGrandTotal();
        }
      });
    }

    const haulingInput = itemBlock.querySelector(".hauling-input");
    if (haulingInput) {
      haulingInput.addEventListener("input", () => {
        this.updateItemTotal(itemNumber);
      });
    }

    this.setupTableCalculations(itemBlock, itemNumber);
  }

  setupTableCalculations(itemBlock, itemNumber) {
    const tables = itemBlock.querySelectorAll(".estimate-table tbody");

    tables.forEach((tbody) => {
      tbody.addEventListener("input", (e) => {
        const row = e.target.closest("tr");
        if (row) {
          this.calculateRowTotal(row);
          this.updateSectionTotal(tbody.closest("table"));
          this.updateItemTotal(itemNumber);
        }
      });
    });
  }

  addTableRow(table, itemNumber) {
    const tbody = table.querySelector("tbody");
    const isEquipmentOrLabor =
      table.id.includes("equipment") || table.id.includes("labor");

    const row = document.createElement("tr");

    if (isEquipmentOrLabor) {
      row.innerHTML = `
                <td><input type="text" placeholder="Enter description"></td>
                <td><input type="number" step="0.01" class="qty" value="0"></td>
                <td><input type="text" class="unit" placeholder="days"></td>
                <td><input type="number" step="0.01" class="crew" value="1"></td>
                <td><input type="number" step="0.01" class="rate" value="0"></td>
                <td class="total-cell">0.00</td>
                <td><button class="btn-remove-row">×</button></td>
            `;
    } else {
      row.innerHTML = `
                <td><input type="text" placeholder="Enter description"></td>
                <td><input type="number" step="0.01" class="qty" value="0"></td>
                <td><input type="text" class="unit" placeholder="unit"></td>
                <td><input type="number" step="0.01" class="rate" value="0"></td>
                <td class="total-cell">0.00</td>
                <td><button class="btn-remove-row">×</button></td>
            `;
    }

    tbody.appendChild(row);

    row.querySelector(".btn-remove-row").addEventListener("click", () => {
      row.remove();
      this.updateSectionTotal(table);
      this.updateItemTotal(itemNumber);
    });

    row.querySelector("input").focus();
  }

  calculateRowTotal(row) {
    const qtyInput = row.querySelector(".qty");
    const rateInput = row.querySelector(".rate");
    const crewInput = row.querySelector(".crew");
    const totalCell = row.querySelector(".total-cell");

    if (!qtyInput || !rateInput || !totalCell) return;

    const qty = parseFloat(qtyInput.value) || 0;
    const rate = parseFloat(rateInput.value) || 0;
    const crew = crewInput ? parseFloat(crewInput.value) || 1 : 1;

    const total = calculateTotal(qty, rate, crew);
    totalCell.textContent = formatCurrency(total);
  }

  updateSectionTotal(table) {
    const tbody = table.querySelector("tbody");
    const rows = tbody.querySelectorAll("tr");

    let sectionTotal = 0;
    rows.forEach((row) => {
      const totalCell = row.querySelector(".total-cell");
      if (totalCell) {
        const value = parseFloat(totalCell.textContent.replace(/,/g, "")) || 0;
        sectionTotal += value;
      }
    });

    return sectionTotal;
  }

  updateItemTotal(itemNumber) {
    const itemBlock = document
      .querySelector(`[data-item="${itemNumber}"]`)
      ?.closest(".item-block");
    if (!itemBlock) return;

    const materialsTable = itemBlock.querySelector('[id*="materials"]');
    const materialsTotal = materialsTable
      ? this.updateSectionTotal(materialsTable)
      : 0;
    itemBlock.querySelector(".materials-total").textContent =
      formatCurrency(materialsTotal);

    const equipmentTable = itemBlock.querySelector('[id*="equipment"]');
    const equipmentTotal = equipmentTable
      ? this.updateSectionTotal(equipmentTable)
      : 0;
    itemBlock.querySelector(".equipment-total").textContent =
      formatCurrency(equipmentTotal);

    const laborTable = itemBlock.querySelector('[id*="labor"]');
    const laborTotal = laborTable ? this.updateSectionTotal(laborTable) : 0;
    itemBlock.querySelector(".labor-total").textContent =
      formatCurrency(laborTotal);

    const hauling =
      parseFloat(itemBlock.querySelector(".hauling-input").value) || 0;

    const itemTotal = materialsTotal + equipmentTotal + laborTotal + hauling;
    itemBlock.querySelector(".item-total").textContent =
      formatCurrency(itemTotal);

    this.updateGrandTotal();
  }

  updateGrandTotal() {
    const itemBlocks = document.querySelectorAll(".item-block");
    let grandTotal = 0;

    itemBlocks.forEach((block) => {
      const itemTotalText = block.querySelector(".item-total").textContent;
      const itemTotal = parseFloat(itemTotalText.replace(/,/g, "")) || 0;
      grandTotal += itemTotal;
    });

    document.getElementById("grandTotal").textContent =
      formatCurrency(grandTotal);
  }

  addNewItem() {
    this.itemCounter++;
    const itemNumber = this.itemCounter;

    const itemsSection = document.querySelector(".items-section");
    const addButton = document.getElementById("addNewItem");

    const newItemBlock = document.createElement("div");
    newItemBlock.className = "item-block";
    newItemBlock.innerHTML = this.getItemBlockTemplate(itemNumber);

    itemsSection.insertBefore(newItemBlock, addButton);
    this.setupItemEventListeners(itemNumber);

    newItemBlock.querySelector(".item-title").focus();
  }

  getItemBlockTemplate(itemNumber) {
    return `
            <div class="item-header">
                <input type="text" class="item-title" value="ITEM ${itemNumber}" data-item="${itemNumber}">
                <button class="btn-remove-item">Remove Item</button>
            </div>
            
            <div class="subsection">
                <input type="text" class="subsection-title materials-title" value="A. Materials">
                <table class="estimate-table" id="item${itemNumber}-materials">
                    <thead>
                        <tr>
                            <th>Item Description</th>
                            <th>Quantity</th>
                            <th>Unit</th>
                            <th>Rate/Unit Cost</th>
                            <th>Total</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="6">
                                <button class="btn-add-row">+ Add Material</button>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>

            <div class="subsection">
                <input type="text" class="subsection-title equipment-title" value="B. Equipment">
                <table class="estimate-table" id="item${itemNumber}-equipment">
                    <thead>
                        <tr>
                            <th>Item Description</th>
                            <th>Quantity</th>
                            <th>Unit</th>
                            <th>No. of Crew/Labor</th>
                            <th>Rate/Day/Unit Cost</th>
                            <th>Total</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="7">
                                <button class="btn-add-row">+ Add Equipment</button>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>

            <div class="subsection">
                <input type="text" class="subsection-title labor-title" value="C. Labor">
                <table class="estimate-table" id="item${itemNumber}-labor">
                    <thead>
                        <tr>
                            <th>Item Description</th>
                            <th>Quantity</th>
                            <th>Unit</th>
                            <th>No. of Crew/Labor</th>
                            <th>Rate/Day/Unit Cost</th>
                            <th>Total</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="7">
                                <button class="btn-add-row">+ Add Labor</button>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>

            <div class="item-summary">
                <div class="summary-row">
                    <span class="summary-materials-label">Materials:</span>
                    <span class="materials-total">0.00</span>
                </div>
                <div class="summary-row">
                    <span class="summary-equipment-label">Equipment:</span>
                    <span class="equipment-total">0.00</span>
                </div>
                <div class="summary-row">
                    <span class="summary-labor-label">Labor:</span>
                    <span class="labor-total">0.00</span>
                </div>
                <div class="summary-row">
                    <span>Hauling:</span>
                    <input type="number" step="0.01" class="hauling-input" value="0">
                </div>
                <div class="summary-row total-row">
                    <span>Total Cost for This Item:</span>
                    <span class="item-total">0.00</span>
                </div>
            </div>
        `;
  }

  updateProjectInfo(field, value) {
    this.data.projectInfo[field] = value;
  }

  updateExportSettings(field, value) {
    this.data.exportSettings[field] = value;
  }

  collectAllData() {
    const projectInfo = {
      province: document.getElementById("province").textContent,
      municipality: document.getElementById("municipality").textContent,
      projectTitle: document.getElementById("projectTitle").value,
      location: document.getElementById("location").value,
      physicalTarget: document.getElementById("physicalTarget").value,
      subject: document.getElementById("subject").value,
    };

    const exportSettings = {
      columnWidthScale: document.getElementById("columnWidthScale").value,
      rowHeightScale: document.getElementById("rowHeightScale").value,
      fontSize: document.getElementById("fontSize").value,
    };

    const items = [];
    document.querySelectorAll(".item-block").forEach((block) => {
      const itemTitle = block.querySelector(".item-title").value;
      const itemNumber = block.querySelector(".item-title").dataset.item;

      const materialsTitle =
        block.querySelector(".materials-title")?.value || "A. Materials";
      const equipmentTitle =
        block.querySelector(".equipment-title")?.value || "B. Equipment";
      const laborTitle =
        block.querySelector(".labor-title")?.value || "C. Labor";

      const materials = this.collectTableData(
        block.querySelector('[id*="materials"]'),
      );
      const equipment = this.collectTableData(
        block.querySelector('[id*="equipment"]'),
      );
      const labor = this.collectTableData(block.querySelector('[id*="labor"]'));
      const hauling =
        parseFloat(block.querySelector(".hauling-input").value) || 0;

      items.push({
        itemNumber,
        title: itemTitle,
        materialsTitle,
        equipmentTitle,
        laborTitle,
        materials,
        equipment,
        labor,
        hauling,
      });
    });

    return { projectInfo, exportSettings, items };
  }

  collectTableData(table) {
    if (!table) return [];

    const rows = table.querySelectorAll("tbody tr");
    const data = [];

    rows.forEach((row) => {
      const inputs = row.querySelectorAll("input");
      if (inputs.length > 0) {
        const rowData = {
          description: inputs[0].value,
          quantity: parseFloat(inputs[1].value) || 0,
          unit: inputs[2].value,
        };

        if (inputs.length > 4) {
          rowData.crew = parseFloat(inputs[3].value) || 1;
          rowData.rate = parseFloat(inputs[4].value) || 0;
        } else {
          rowData.rate = parseFloat(inputs[3].value) || 0;
        }

        data.push(rowData);
      }
    });

    return data;
  }

  saveToLocalStorage() {
    const data = this.collectAllData();
    saveEstimate(data);
    alert("Estimate saved successfully!");
  }

  loadFromLocalStorage() {
    const data = loadEstimate();
    if (data) {
      this.loadData(data);
      alert("Estimate loaded successfully!");
    } else {
      alert("No saved estimate found.");
    }
  }

  loadData(data) {
    if (data.projectInfo) {
      document.getElementById("projectTitle").value =
        data.projectInfo.projectTitle || "";
      document.getElementById("location").value =
        data.projectInfo.location || "";
      document.getElementById("physicalTarget").value =
        data.projectInfo.physicalTarget || "";
    }

    if (data.exportSettings) {
      document.getElementById("columnWidthScale").value =
        data.exportSettings.columnWidthScale || "standard";
      document.getElementById("rowHeightScale").value =
        data.exportSettings.rowHeightScale || "standard";
      document.getElementById("fontSize").value =
        data.exportSettings.fontSize || "10";
    }

    if (data.items && data.items.length > 0) {
      const itemsSection = document.querySelector(".items-section");
      document
        .querySelectorAll(".item-block")
        .forEach((block) => block.remove());
      this.itemCounter = 0;

      data.items.forEach((itemData) => {
        this.itemCounter = Math.max(
          this.itemCounter,
          parseInt(itemData.itemNumber) || 0,
        );

        const addButton = document.getElementById("addNewItem");
        const newItemBlock = document.createElement("div");
        newItemBlock.className = "item-block";
        newItemBlock.innerHTML = this.getItemBlockTemplate(itemData.itemNumber);

        newItemBlock.querySelector(".item-title").value = itemData.title;

        // Restore custom titles
        if (itemData.materialsTitle) {
          newItemBlock.querySelector(".materials-title").value =
            itemData.materialsTitle;
          newItemBlock.querySelector(".summary-materials-label").textContent =
            itemData.materialsTitle.replace(/^[A-Z]\.\s*/, "") + ":";
        }
        if (itemData.equipmentTitle) {
          newItemBlock.querySelector(".equipment-title").value =
            itemData.equipmentTitle;
          newItemBlock.querySelector(".summary-equipment-label").textContent =
            itemData.equipmentTitle.replace(/^[A-Z]\.\s*/, "") + ":";
        }
        if (itemData.laborTitle) {
          newItemBlock.querySelector(".labor-title").value =
            itemData.laborTitle;
          newItemBlock.querySelector(".summary-labor-label").textContent =
            itemData.laborTitle.replace(/^[A-Z]\.\s*/, "") + ":";
        }

        itemsSection.insertBefore(newItemBlock, addButton);
        this.setupItemEventListeners(itemData.itemNumber);

        this.populateTable(
          newItemBlock.querySelector('[id*="materials"]'),
          itemData.materials,
          false,
          itemData.itemNumber,
        );
        this.populateTable(
          newItemBlock.querySelector('[id*="equipment"]'),
          itemData.equipment,
          true,
          itemData.itemNumber,
        );
        this.populateTable(
          newItemBlock.querySelector('[id*="labor"]'),
          itemData.labor,
          true,
          itemData.itemNumber,
        );

        newItemBlock.querySelector(".hauling-input").value =
          itemData.hauling || 0;

        this.updateItemTotal(itemData.itemNumber);
      });
    }
  }

  populateTable(table, rowsData, isEquipmentOrLabor, itemNumber) {
    if (!table || !rowsData || rowsData.length === 0) return;
    const tbody = table.querySelector("tbody");
    tbody.innerHTML = "";

    rowsData.forEach((rowData) => {
      const row = document.createElement("tr");
      if (isEquipmentOrLabor) {
        row.innerHTML = `
            <td><input type="text" placeholder="Enter description" value="${rowData.description || ""}"></td>
            <td><input type="number" step="0.01" class="qty" value="${rowData.quantity || 0}"></td>
            <td><input type="text" class="unit" placeholder="days" value="${rowData.unit || ""}"></td>
            <td><input type="number" step="0.01" class="crew" value="${rowData.crew || 1}"></td>
            <td><input type="number" step="0.01" class="rate" value="${rowData.rate || 0}"></td>
            <td class="total-cell">0.00</td>
            <td><button class="btn-remove-row">×</button></td>
        `;
      } else {
        row.innerHTML = `
            <td><input type="text" placeholder="Enter description" value="${rowData.description || ""}"></td>
            <td><input type="number" step="0.01" class="qty" value="${rowData.quantity || 0}"></td>
            <td><input type="text" class="unit" placeholder="unit" value="${rowData.unit || ""}"></td>
            <td><input type="number" step="0.01" class="rate" value="${rowData.rate || 0}"></td>
            <td class="total-cell">0.00</td>
            <td><button class="btn-remove-row">×</button></td>
        `;
      }
      tbody.appendChild(row);

      row.querySelector(".btn-remove-row").addEventListener("click", () => {
        row.remove();
        this.updateSectionTotal(table);
        this.updateItemTotal(itemNumber);
      });

      this.calculateRowTotal(row);
    });
  }

  loadSampleData() {
    document.getElementById("projectTitle").value =
      "PROPOSED STORE DISPLAY SHELTER";
    document.getElementById("location").value =
      "BRGY. STO. NIÑO, TUKURAN, ZAMBOANGA DEL SUR";
    document.getElementById("physicalTarget").value = "1.00 lot";
  }

  exportToExcel() {
    const data = this.collectAllData();
    exportToExcel(data);
  }

  newEstimate() {
    if (
      confirm(
        "Are you sure you want to create a new estimate? Any unsaved changes will be lost.",
      )
    ) {
      location.reload();
    }
  }
}

document.addEventListener("DOMContentLoaded", () => {
  new EstimateBuilder();
});
