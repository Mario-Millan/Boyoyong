/**
 * Calculation Utilities
 * Helper functions for mathematical operations and formatting
 */

/**
 * Calculate total from quantity and rate
 * @param {number} quantity - The quantity
 * @param {number} rate - The rate per unit
 * @param {number} crew - Number of crew (default 1)
 * @returns {number} Total amount
 */
export function calculateTotal(quantity, rate, crew = 1) {
  const qty = parseFloat(quantity) || 0;
  const rateVal = parseFloat(rate) || 0;
  const crewVal = parseFloat(crew) || 1;

  return qty * rateVal * crewVal;
}

/**
 * Format number as currency with thousand separators
 * @param {number} amount - The amount to format
 * @param {number} decimals - Number of decimal places (default 2)
 * @returns {string} Formatted currency string
 */
export function formatCurrency(amount, decimals = 2) {
  const num = parseFloat(amount) || 0;
  return num.toFixed(decimals).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

/**
 * Parse currency string to number
 * @param {string} currencyString - The formatted currency string
 * @returns {number} Numeric value
 */
export function parseCurrency(currencyString) {
  if (typeof currencyString === "number") return currencyString;
  const cleaned = String(currencyString).replace(/[^0-9.-]/g, "");
  return parseFloat(cleaned) || 0;
}

/**
 * Sum an array of numbers
 * @param {Array<number>} numbers - Array of numbers to sum
 * @returns {number} Total sum
 */
export function sumArray(numbers) {
  return numbers.reduce((acc, val) => acc + (parseFloat(val) || 0), 0);
}

/**
 * Calculate percentage
 * @param {number} part - The part value
 * @param {number} whole - The whole value
 * @returns {number} Percentage (0-100)
 */
export function calculatePercentage(part, whole) {
  if (!whole || whole === 0) return 0;
  return (parseFloat(part) / parseFloat(whole)) * 100;
}

/**
 * Round to specified decimal places
 * @param {number} value - The value to round
 * @param {number} decimals - Number of decimal places
 * @returns {number} Rounded value
 */
export function roundTo(value, decimals = 2) {
  const multiplier = Math.pow(10, decimals);
  return Math.round((parseFloat(value) || 0) * multiplier) / multiplier;
}
