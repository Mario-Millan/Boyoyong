/**
 * Storage Utility
 * Handles saving and loading estimate data to/from localStorage
 */

const STORAGE_KEY = "estimate_builder_data";
const RECENT_ESTIMATES_KEY = "estimate_builder_recent";

/**
 * Save estimate to localStorage
 * @param {Object} data - The estimate data to save
 * @returns {boolean} Success status
 */
export function saveEstimate(data) {
  try {
    const timestamp = new Date().toISOString();
    const estimateData = {
      ...data,
      savedAt: timestamp,
    };

    localStorage.setItem(STORAGE_KEY, JSON.stringify(estimateData));

    // Update recent estimates list
    saveToRecentList(data.projectInfo.projectTitle || "Untitled", timestamp);

    return true;
  } catch (error) {
    console.error("Error saving estimate:", error);
    return false;
  }
}

/**
 * Load estimate from localStorage
 * @returns {Object|null} The estimate data or null if not found
 */
export function loadEstimate() {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : null;
  } catch (error) {
    console.error("Error loading estimate:", error);
    return null;
  }
}

/**
 * Clear current estimate from localStorage
 * @returns {boolean} Success status
 */
export function clearEstimate() {
  try {
    localStorage.removeItem(STORAGE_KEY);
    return true;
  } catch (error) {
    console.error("Error clearing estimate:", error);
    return false;
  }
}

/**
 * Save estimate to a named slot
 * @param {string} name - Name for this estimate
 * @param {Object} data - The estimate data
 * @returns {boolean} Success status
 */
export function saveEstimateAs(name, data) {
  try {
    const timestamp = new Date().toISOString();
    const key = `estimate_${name.replace(/[^a-z0-9]/gi, "_")}`;

    const estimateData = {
      ...data,
      name: name,
      savedAt: timestamp,
    };

    localStorage.setItem(key, JSON.stringify(estimateData));
    saveToRecentList(name, timestamp, key);

    return true;
  } catch (error) {
    console.error("Error saving named estimate:", error);
    return false;
  }
}

/**
 * Load estimate from a named slot
 * @param {string} key - The storage key
 * @returns {Object|null} The estimate data or null
 */
export function loadEstimateByKey(key) {
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : null;
  } catch (error) {
    console.error("Error loading named estimate:", error);
    return null;
  }
}

/**
 * Get list of recent estimates
 * @returns {Array} Array of recent estimate metadata
 */
export function getRecentEstimates() {
  try {
    const data = localStorage.getItem(RECENT_ESTIMATES_KEY);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error("Error getting recent estimates:", error);
    return [];
  }
}

/**
 * Save to recent estimates list
 * @param {string} title - Estimate title
 * @param {string} timestamp - Save timestamp
 * @param {string} key - Storage key
 */
function saveToRecentList(title, timestamp, key = STORAGE_KEY) {
  try {
    let recent = getRecentEstimates();

    // Remove existing entry with same key
    recent = recent.filter((item) => item.key !== key);

    // Add new entry at the beginning
    recent.unshift({
      title,
      timestamp,
      key,
    });

    // Keep only last 10
    recent = recent.slice(0, 10);

    localStorage.setItem(RECENT_ESTIMATES_KEY, JSON.stringify(recent));
  } catch (error) {
    console.error("Error updating recent list:", error);
  }
}

/**
 * Delete an estimate
 * @param {string} key - The storage key to delete
 * @returns {boolean} Success status
 */
export function deleteEstimate(key) {
  try {
    localStorage.removeItem(key);

    // Remove from recent list
    let recent = getRecentEstimates();
    recent = recent.filter((item) => item.key !== key);
    localStorage.setItem(RECENT_ESTIMATES_KEY, JSON.stringify(recent));

    return true;
  } catch (error) {
    console.error("Error deleting estimate:", error);
    return false;
  }
}

/**
 * Export all estimates as JSON
 * @returns {string} JSON string of all estimates
 */
export function exportAllEstimates() {
  try {
    const allEstimates = {};

    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key.startsWith("estimate_")) {
        allEstimates[key] = JSON.parse(localStorage.getItem(key));
      }
    }

    return JSON.stringify(allEstimates, null, 2);
  } catch (error) {
    console.error("Error exporting estimates:", error);
    return null;
  }
}

/**
 * Import estimates from JSON
 * @param {string} jsonData - JSON string containing estimates
 * @returns {boolean} Success status
 */
export function importEstimates(jsonData) {
  try {
    const estimates = JSON.parse(jsonData);

    Object.keys(estimates).forEach((key) => {
      localStorage.setItem(key, JSON.stringify(estimates[key]));
    });

    return true;
  } catch (error) {
    console.error("Error importing estimates:", error);
    return false;
  }
}

/**
 * Get storage usage information
 * @returns {Object} Storage usage stats
 */
export function getStorageInfo() {
  try {
    let totalSize = 0;
    let estimateCount = 0;

    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key.startsWith("estimate_")) {
        const item = localStorage.getItem(key);
        totalSize += item.length;
        estimateCount++;
      }
    }

    return {
      estimateCount,
      totalSize,
      totalSizeKB: (totalSize / 1024).toFixed(2),
      availableSpace: 5 * 1024 * 1024 - totalSize, // Assuming 5MB limit
    };
  } catch (error) {
    console.error("Error getting storage info:", error);
    return null;
  }
}
