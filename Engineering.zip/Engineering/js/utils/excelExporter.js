/**
 * Excel Export Utility
 * Uses ExcelJS to dynamically generate a highly stylized Excel file matching the reference design.
 */

export async function exportToExcel(data) {
  const { projectInfo, items } = data;

  // 1. Create a new workbook and worksheet
  const workbook = new ExcelJS.Workbook();
  const ws = workbook.addWorksheet("Detailed Estimate", {
    pageSetup: {
      paperSize: 9,
      orientation: "portrait",
      fitToPage: true,
      fitToWidth: 1,
    },
  });

  // 2. Set strict column widths to match the printed layout
  ws.columns = [
    { key: "A", width: 12 }, // ITEM NO.
    { key: "B", width: 50 }, // ITEM DESCRIPTION
    { key: "C", width: 12 }, // QUANTITY
    { key: "D", width: 10 }, // UNIT
    { key: "E", width: 15 }, // No. of Crew
    { key: "F", width: 18 }, // RATE
    { key: "G", width: 20 }, // TOTAL
  ];

  // --- STYLE DEFINITIONS ---
  const borderThin = {
    top: { style: "thin" },
    left: { style: "thin" },
    bottom: { style: "thin" },
    right: { style: "thin" },
  };

  const fillGreen = {
    type: "pattern",
    pattern: "solid",
    fgColor: { argb: "FF00FF00" }, // Fixed Neon Green
  }; 
  const fillYellow = {
    type: "pattern",
    pattern: "solid",
    fgColor: { argb: "FFFFFF00" }, // Fixed Bright Yellow
  }; 
  const fillLightGray = {
    type: "pattern",
    pattern: "solid",
    fgColor: { argb: "FFF2F2F2" },
  };

  // 3. Header Section (Centered over the document)
  ws.addRow(["Republic of the Philippines"]).font = { size: 10 };
  ws.addRow([projectInfo.province || "PROVINCE OF ZAMBOANGA DEL SUR"]).font = {
    bold: true,
    size: 10,
  };
  ws.addRow([projectInfo.municipality || "Municipality of Tukuran"]).font = {
    size: 10,
  };
  ws.addRow([]);

  // Merge top headers across all columns
  ws.mergeCells("A1:G1");
  ws.getCell("A1").alignment = { horizontal: "center" };
  ws.mergeCells("A2:G2");
  ws.getCell("A2").alignment = { horizontal: "center" };
  ws.mergeCells("A3:G3");
  ws.getCell("A3").alignment = { horizontal: "center" };

  // Project Details
  ws.getCell('A5').value = "Project Title";
  ws.getCell('A5').font = { bold: true };
  ws.getCell('B5').value = projectInfo.projectTitle || "";
  ws.getCell('B5').font = { bold: true };
  
  ws.getCell('A6').value = "Location";
  ws.getCell('A6').font = { bold: true };
  ws.getCell('B6').value = projectInfo.location || "";
  ws.getCell('B6').font = { bold: true };
  
  ws.getCell('A7').value = "Physical Target";
  ws.getCell('A7').font = { bold: true };
  ws.getCell('C7').value = projectInfo.physicalTarget || ""; 
  ws.getCell('C7').font = { bold: true };
  
  ws.getCell('A8').value = "Subject";
  ws.getCell('A8').font = { bold: true };
  ws.getCell('B8').value = projectInfo.subject || "Detailed Estimate";
  ws.getCell('B8').font = { bold: true };

  ws.addRow([]); // Blank row before table headers

  // 4. Main Table Headers
  const headerRow = ws.addRow([
    "ITEM NO.",
    "ITEM DESCRIPTION",
    "QUANTITY",
    "UNIT",
    "No. of Crew \n/ Labor",
    "RATE PER DAY / \nUNIT COST",
    "TOTAL",
  ]);

  headerRow.height = 30; // Added height for wrap text
  headerRow.font = { bold: true, size: 9 };
  headerRow.alignment = {
    horizontal: "center",
    vertical: "middle",
    wrapText: true,
  };
  headerRow.fill = fillLightGray;
  headerRow.eachCell((cell) => {
    cell.border = borderThin;
  });

  // 5. Iterate through items
  let grandTotal = 0;

  items.forEach((item) => {
    // Calculate totals first so we can put the item total on the green header row
    let materialsTotal = 0, equipmentTotal = 0, laborTotal = 0;
    
    if (item.materials) {
        item.materials.forEach(mat => materialsTotal += (mat.quantity * mat.rate));
    }
    if (item.equipment) {
        item.equipment.forEach(eq => equipmentTotal += (eq.quantity * eq.rate * (eq.crew || 1)));
    }
    if (item.labor) {
        item.labor.forEach(lab => laborTotal += (lab.quantity * lab.rate * (lab.crew || 1)));
    }
    
    const hauling = item.hauling || 0;
    const itemTotal = materialsTotal + equipmentTotal + laborTotal + hauling;
    grandTotal += itemTotal;

    // --- GREEN ITEM HEADER ---
    const itemRow = ws.addRow([
      item.itemNumber || "",
      item.title || "ITEM",
      "1.00", // Defaulting as seen in reference
      "lot.", // Defaulting as seen in reference
      "",
      "",
      itemTotal, // Total placed directly on the green header
    ]);
    itemRow.font = { bold: true, color: { argb: "FF000000" } }; // Black text
    itemRow.fill = fillGreen;
    itemRow.eachCell((cell, colNum) => {
      cell.border = borderThin;
      if (colNum === 3 || colNum === 4) cell.alignment = { horizontal: "center" };
      if (colNum === 7) {
          cell.alignment = { horizontal: "right" };
          cell.numFmt = "#,##0.00";
      }
    });

    // --- MATERIALS SECTION (YELLOW) ---
    if (item.materials && item.materials.length > 0) {
      const matTitleRow = ws.addRow([
        "",
        item.materialsTitle || "A. Materials",
        "",
        "",
        "",
        "",
        "",
      ]);
      matTitleRow.font = { bold: true };
      matTitleRow.fill = fillYellow;
      matTitleRow.eachCell((cell) => {
        cell.border = borderThin;
      });

      item.materials.forEach((mat) => {
        const total = mat.quantity * mat.rate;
        const row = ws.addRow([
          "",
          mat.description,
          mat.quantity,
          mat.unit,
          "",
          mat.rate,
          total,
        ]);
        row.eachCell((cell) => {
          cell.border = borderThin;
        });
        row.getCell(3).alignment = { horizontal: "center" };
        row.getCell(4).alignment = { horizontal: "center" };
        row.getCell(6).numFmt = "#,##0.00";
        row.getCell(7).numFmt = "#,##0.00";
      });
    }

    // --- EQUIPMENT SECTION (YELLOW) ---
    if (item.equipment && item.equipment.length > 0) {
      const eqTitleRow = ws.addRow([
        "",
        item.equipmentTitle || "B. Equipment",
        "",
        "",
        "",
        "",
        "",
      ]);
      eqTitleRow.font = { bold: true };
      eqTitleRow.fill = fillYellow;
      eqTitleRow.eachCell((cell) => {
        cell.border = borderThin;
      });

      item.equipment.forEach((eq) => {
        const total = eq.quantity * eq.rate * (eq.crew || 1);
        const row = ws.addRow([
          "",
          eq.description,
          eq.quantity,
          eq.unit,
          eq.crew || 1,
          eq.rate,
          total,
        ]);
        row.eachCell((cell) => {
          cell.border = borderThin;
        });
        row.getCell(3).alignment = { horizontal: "center" };
        row.getCell(4).alignment = { horizontal: "center" };
        row.getCell(5).alignment = { horizontal: "center" };
        row.getCell(6).numFmt = "#,##0.00";
        row.getCell(7).numFmt = "#,##0.00";
      });
    }

    // --- LABOR SECTION (YELLOW) ---
    if (item.labor && item.labor.length > 0) {
      const labTitleRow = ws.addRow([
        "",
        item.laborTitle || "C. Labor",
        "",
        "",
        "",
        "",
        "",
      ]);
      labTitleRow.font = { bold: true };
      labTitleRow.fill = fillYellow;
      labTitleRow.eachCell((cell) => {
        cell.border = borderThin;
      });

      item.labor.forEach((lab) => {
        const total = lab.quantity * lab.rate * (lab.crew || 1);
        const row = ws.addRow([
          "",
          lab.description,
          lab.quantity,
          lab.unit,
          lab.crew || 1,
          lab.rate,
          total,
        ]);
        row.eachCell((cell) => {
          cell.border = borderThin;
        });
        row.getCell(3).alignment = { horizontal: "center" };
        row.getCell(4).alignment = { horizontal: "center" };
        row.getCell(5).alignment = { horizontal: "center" };
        row.getCell(6).numFmt = "#,##0.00";
        row.getCell(7).numFmt = "#,##0.00";
      });
    }

    // --- ITEM SUMMARY BLOCK ---
    // Blank spacer row with borders in columns
    let emptyRow = ws.addRow(["", "", "", "", "", "", ""]);
    emptyRow.eachCell((cell) => {
      cell.border = borderThin;
    });

    // Totals Breakdown
    const breakDownData = [
      { label: "Materials:", val: materialsTotal },
      { label: "Equipments:", val: equipmentTotal },
      { label: "Labor:", val: laborTotal },
      { label: "Hauling:", val: hauling },
    ];

    breakDownData.forEach((bd) => {
      let r = ws.addRow(["", "", "", "", "", bd.label, bd.val]);
      r.eachCell((cell) => {
        cell.border = borderThin;
      });
      r.getCell(6).alignment = { horizontal: "right" };
      if(bd.val === 0) {
         r.getCell(7).value = "-"; // Dash for zero values
         r.getCell(7).alignment = { horizontal: "right" };
      } else {
         r.getCell(7).numFmt = "#,##0.00";
      }
    });

    // Sub-total Yellow Bar
    const subTotalRow = ws.addRow([
      "",
      `Total Cost for Item ${item.itemNumber || ""} ...........................`,
      "",
      "",
      "",
      "",
      itemTotal,
    ]);
    subTotalRow.font = { bold: true };
    subTotalRow.fill = fillYellow;
    subTotalRow.eachCell((cell) => {
      cell.border = borderThin;
    });
    // Merge the text visually like the reference
    ws.mergeCells(`B${subTotalRow.number}:F${subTotalRow.number}`);
    subTotalRow.getCell(2).alignment = { horizontal: "right" };
    subTotalRow.getCell(7).numFmt = "#,##0.00";

    // Add an empty row between items (no borders)
    ws.addRow([]);
  });

  // 6. GRAND TOTAL ROW
  const grandTotalRow = ws.addRow([
    "",
    "TOTAL DIRECT COST ...........................",
    "",
    "",
    "",
    "",
    grandTotal,
  ]);
  grandTotalRow.font = { bold: true };
  grandTotalRow.fill = fillYellow;
  grandTotalRow.eachCell((cell) => {
    cell.border = borderThin;
  });
  ws.mergeCells(`B${grandTotalRow.number}:F${grandTotalRow.number}`);
  grandTotalRow.getCell(2).alignment = { horizontal: "right" };
  grandTotalRow.getCell(7).numFmt = "#,##0.00";

  // 7. Save and Download the file
  try {
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    const filename = generateFilename(projectInfo);
    window.saveAs(blob, filename);
  } catch (err) {
    console.error("Error generating Excel file:", err);
    alert("There was an error exporting the Excel file.");
  }
}

function generateFilename(projectInfo) {
  const title = projectInfo.projectTitle || "Estimate";
  const date = new Date().toISOString().split("T")[0];
  const sanitized = title.replace(/[^a-z0-9]/gi, "_").substring(0, 50);
  return `${sanitized}_${date}.xlsx`;
}