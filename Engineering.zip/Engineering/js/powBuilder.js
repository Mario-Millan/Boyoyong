import { exportPOWToExcel } from './powExporter.js';

class POWBuilder {
    constructor() {
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.calculateTotals();
    }

    setupEventListeners() {
        document.getElementById('exportPowExcel').addEventListener('click', () => this.exportToExcel());

        // Dynamic Lists (Equipment & Personnel)
        document.getElementById('addEqBtn').addEventListener('click', () => this.addListRow('equipmentList'));
        document.getElementById('addPersBtn').addEventListener('click', () => this.addListRow('personnelList'));
        
        document.querySelectorAll('.dynamic-list').forEach(list => {
            list.addEventListener('click', (e) => {
                if (e.target.classList.contains('btn-remove-row')) e.target.parentElement.remove();
            });
        });

        // Scope of Works Table
        document.getElementById('addPowItemBtn').addEventListener('click', () => this.addScopeRow());
        document.getElementById('powItemsTable').addEventListener('input', (e) => {
            if (e.target.classList.contains('pow-item-qty') || e.target.classList.contains('pow-item-cost')) {
                this.calculateRowTotal(e.target.closest('tr'));
            }
        });
        document.getElementById('powItemsTable').addEventListener('click', (e) => {
            if (e.target.classList.contains('btn-remove-row')) {
                e.target.closest('tr').remove();
            }
        });

        // Direct Cost Inputs
        document.querySelectorAll('.cost-input').forEach(input => {
            input.addEventListener('input', () => this.calculateTotals());
        });
    }

    addListRow(containerId) {
        const container = document.getElementById(containerId);
        const div = document.createElement('div');
        div.className = 'dynamic-list-item';
        div.innerHTML = `<input type="text" placeholder="Enter item"><button class="btn-remove-row">×</button>`;
        container.appendChild(div);
    }

    addScopeRow() {
        const tbody = document.querySelector('#powItemsTable tbody');
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td><input type="text" class="pow-item-no" placeholder="Item"></td>
            <td><input type="text" class="pow-item-desc" placeholder="Description"></td>
            <td><input type="number" class="pow-item-qty" value="0"></td>
            <td><input type="text" class="pow-item-unit" placeholder="unit"></td>
            <td><input type="number" class="pow-item-cost" value="0"></td>
            <td class="pow-item-total" style="font-weight: bold; text-align: right; padding-right: 1rem;">0.00</td>
            <td><button class="btn-remove-row">×</button></td>
        `;
        tbody.appendChild(tr);
    }

    calculateRowTotal(row) {
        const qty = parseFloat(row.querySelector('.pow-item-qty').value) || 0;
        const cost = parseFloat(row.querySelector('.pow-item-cost').value) || 0;
        const total = qty * cost;
        row.querySelector('.pow-item-total').textContent = total.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
    }

    calculateTotals() {
        const mat = parseFloat(document.getElementById('costMaterials').value) || 0;
        const lab = parseFloat(document.getElementById('costLabor').value) || 0;
        const eq = parseFloat(document.getElementById('costEquipment').value) || 0;
        const haul = parseFloat(document.getElementById('costHauling').value) || 0;
        const totalDirect = mat + lab + eq + haul;
        
        document.getElementById('displayDirectCost').textContent = totalDirect.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
    }

    collectData() {
        const data = {
            projectInfo: {
                title: document.getElementById('powTitle').value,
                location: document.getElementById('powLocation').value,
                target: document.getElementById('powTarget').value,
                fund: document.getElementById('powFund').value,
                duration: document.getElementById('powDuration').value,
                description: document.getElementById('powDescription').value
            },
            costs: {
                materials: parseFloat(document.getElementById('costMaterials').value) || 0,
                labor: parseFloat(document.getElementById('costLabor').value) || 0,
                equipment: parseFloat(document.getElementById('costEquipment').value) || 0,
                hauling: parseFloat(document.getElementById('costHauling').value) || 0
            },
            percentages: {
                contingency: parseFloat(document.getElementById('pctContingency').value) || 0,
                profit: parseFloat(document.getElementById('pctProfit').value) || 0,
                taxes: parseFloat(document.getElementById('pctTaxes').value) || 0,
                supervision: parseFloat(document.getElementById('pctSupervision').value) || 0
            },
            equipmentList: Array.from(document.querySelectorAll('#equipmentList input')).map(inp => inp.value).filter(v => v),
            personnelList: Array.from(document.querySelectorAll('#personnelList input')).map(inp => inp.value).filter(v => v),
            scopeItems: [],
            signatories: {
                prepName: document.getElementById('sigPrepName').value,
                prepTitle: document.getElementById('sigPrepTitle').value,
                checkName: document.getElementById('sigCheckName').value,
                checkTitle: document.getElementById('sigCheckTitle').value,
                revName: document.getElementById('sigRevName').value,
                revTitle: document.getElementById('sigRevTitle').value,
                prioName: document.getElementById('sigPrioName').value,
                prioTitle: document.getElementById('sigPrioTitle').value,
                recName: document.getElementById('sigRecName').value,
                recTitle: document.getElementById('sigRecTitle').value,
                appName: document.getElementById('sigAppName').value,
                appTitle: document.getElementById('sigAppTitle').value
            }
        };

        document.querySelectorAll('#powItemsTable tbody tr').forEach(row => {
            data.scopeItems.push({
                itemNo: row.querySelector('.pow-item-no').value,
                desc: row.querySelector('.pow-item-desc').value,
                qty: parseFloat(row.querySelector('.pow-item-qty').value) || 0,
                unit: row.querySelector('.pow-item-unit').value,
                unitCost: parseFloat(row.querySelector('.pow-item-cost').value) || 0
            });
        });

        return data;
    }

    exportToExcel() {
        const data = this.collectData();
        exportPOWToExcel(data);
    }
}

document.addEventListener('DOMContentLoaded', () => new POWBuilder());