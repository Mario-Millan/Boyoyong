/**
 * Excel Export Utility for Program of Works
 * Built using the EXACT safe structure from the working Detailed Estimate exporter.
 */

export async function exportPOWToExcel(data) {
  // 1. Create a new workbook and worksheet
  const workbook = new ExcelJS.Workbook();
  const ws = workbook.addWorksheet("Program of Works", {
    pageSetup: {
      paperSize: 9,
      orientation: "portrait",
      fitToPage: true,
      fitToWidth: 1,
      margins: { left: 0.25, right: 0.25, top: 0.5, bottom: 0.5 },
    },
  });

  // 2. Set strict column widths exactly like the reference to avoid squishing
  ws.columns = [
    { key: "A", width: 8 },  // ITEM
    { key: "B", width: 45 }, // SCOPE OF WORKS / Details (Malapad)
    { key: "C", width: 10 }, // % Wt / Const Cost
    { key: "D", width: 10 }, // QTY / BLGU In kind
    { key: "E", width: 10 }, // UNIT / BLGU Cash
    { key: "F", width: 14 }, // UNIT COST / MLGU In kind
    { key: "G", width: 15 }, // TOTAL / MLGU Cash
    { key: "H", width: 15 }, // ADJUSTED COST / Nat'l Funds
    { key: "I", width: 15 }, // TOTAL BREAKDOWN
  ];

  // --- STYLE DEFINITIONS ---
  const borderThin = {
    top: { style: "thin" },
    left: { style: "thin" },
    bottom: { style: "thin" },
    right: { style: "thin" },
  };

  const fillGreen = {
    type: "pattern",
    pattern: "solid",
    fgColor: { argb: "FF92D050" },
  };
  const fillYellow = {
    type: "pattern",
    pattern: "solid",
    fgColor: { argb: "FFFFFF00" },
  };
  const fillLightGray = {
    type: "pattern",
    pattern: "solid",
    fgColor: { argb: "FFF2F2F2" },
  };

  // --- SAFE COMPUTATIONS (Prevents NaN corruption in Excel) ---
  const materials = parseFloat(data?.costs?.materials) || 0;
  const labor = parseFloat(data?.costs?.labor) || 0;
  const equipment = parseFloat(data?.costs?.equipment) || 0;
  const hauling = parseFloat(data?.costs?.hauling) || 0;
  const dCost = materials + labor + equipment + hauling;

  const contPct = parseFloat(data?.percentages?.contingency) || 5;
  const profPct = parseFloat(data?.percentages?.profit) || 8;
  const taxPct = parseFloat(data?.percentages?.taxes) || 5;
  const supPct = parseFloat(data?.percentages?.supervision) || 1;
  const targetQty = parseFloat(data?.projectInfo?.target) || 1;

  const contingencies = dCost * (contPct / 100);
  const profit = dCost * (profPct / 100);
  const taxes = (dCost + contingencies + profit) * (taxPct / 100);
  const totalContract = dCost + contingencies + profit + taxes;
  const engSup = totalContract * (supPct / 100);
  const totalProjectCost = totalContract + engSup;
  const costParam = totalProjectCost / targetQty;

  // 3. Header Section (Centered over the document)
  const r1 = ws.addRow(["REPUBLIC OF THE PHILIPPINES", "", "", "", "", "", "", "", ""]);
  r1.font = { bold: true, size: 11 };
  const r2 = ws.addRow(["Province of Zamboanga del Sur, REGION IX", "", "", "", "", "", "", "", ""]);
  r2.font = { size: 11 };
  const r3 = ws.addRow(["Municipality of TUKURAN", "", "", "", "", "", "", "", ""]);
  r3.font = { size: 11 };
  ws.addRow([]);

  ws.mergeCells(`A${r1.number}:I${r1.number}`); r1.getCell(1).alignment = { horizontal: "center" };
  ws.mergeCells(`A${r2.number}:I${r2.number}`); r2.getCell(1).alignment = { horizontal: "center" };
  ws.mergeCells(`A${r3.number}:I${r3.number}`); r3.getCell(1).alignment = { horizontal: "center" };

  const titleRow = ws.addRow(["PROGRAM OF WORKS", "", "", "", "", "", "", "", ""]);
  ws.mergeCells(`A${titleRow.number}:I${titleRow.number}`);
  titleRow.font = { bold: true, size: 14 };
  titleRow.alignment = { horizontal: "center", vertical: "middle" };
  titleRow.height = 25;

  // 4. Project Details Box (Dynamic Merging to prevent repair errors)
  let r6 = ws.addRow(["PROJECT TITLE", data?.projectInfo?.title || "", "", "", "Sub-Project Duration:", "", `${data?.projectInfo?.duration || 0} Calendar Days`, "", ""]);
  ws.mergeCells(`B${r6.number}:D${r6.number}`); ws.mergeCells(`E${r6.number}:F${r6.number}`); ws.mergeCells(`G${r6.number}:I${r6.number}`);
  r6.eachCell((cell) => { cell.border = borderThin; });
  r6.getCell(1).font = { bold: true }; r6.getCell(2).font = { bold: true }; r6.getCell(2).alignment = { wrapText: true };

  let r7 = ws.addRow(["LOCATION", data?.projectInfo?.location || "", "", "", "Equipment/Tools Needed", "", data?.equipmentList?.[0] || "", "", ""]);
  ws.mergeCells(`B${r7.number}:D${r7.number}`); ws.mergeCells(`E${r7.number}:F${r7.number}`); ws.mergeCells(`G${r7.number}:I${r7.number}`);
  r7.eachCell((cell) => { cell.border = borderThin; });
  r7.getCell(1).font = { bold: true }; r7.getCell(2).alignment = { wrapText: true };

  let r8 = ws.addRow(["Physical Target", `${targetQty} sq.m`, "", "", "", "", data?.equipmentList?.[1] || "", "", ""]);
  ws.mergeCells(`B${r8.number}:D${r8.number}`); ws.mergeCells(`E${r8.number}:F${r8.number}`); ws.mergeCells(`G${r8.number}:I${r8.number}`);
  r8.eachCell((cell) => { cell.border = borderThin; });
  r8.getCell(1).font = { bold: true };

  let r9 = ws.addRow(["Cost parameter", costParam, "", "", "", "", data?.equipmentList?.[2] || "", "", ""]);
  ws.mergeCells(`B${r9.number}:D${r9.number}`); ws.mergeCells(`E${r9.number}:F${r9.number}`); ws.mergeCells(`G${r9.number}:I${r9.number}`);
  r9.eachCell((cell) => { cell.border = borderThin; });
  r9.getCell(2).numFmt = "#,##0.00";

  let r10 = ws.addRow(["Total Sub-Project Cost", totalProjectCost, "", "", "", "", data?.equipmentList?.[3] || "", "", ""]);
  ws.mergeCells(`B${r10.number}:D${r10.number}`); ws.mergeCells(`E${r10.number}:F${r10.number}`); ws.mergeCells(`G${r10.number}:I${r10.number}`);
  r10.eachCell((cell) => { cell.border = borderThin; });
  r10.getCell(2).numFmt = "#,##0.00"; r10.getCell(2).font = { bold: true };

  let r11 = ws.addRow(["PROJECT DESCRIPTION:", "", "", "", "Technical Personnel", "", data?.personnelList?.[0] || "", "", ""]);
  ws.mergeCells(`A${r11.number}:D${r11.number}`); ws.mergeCells(`E${r11.number}:F${r11.number}`); ws.mergeCells(`G${r11.number}:I${r11.number}`);
  r11.eachCell((cell) => { cell.border = borderThin; });
  r11.getCell(1).font = { bold: true };

  let r12 = ws.addRow([data?.projectInfo?.description || "", "", "", "", "", "", data?.personnelList?.[1] || "", "", ""]);
  ws.mergeCells(`E${r12.number}:F${r12.number}`); ws.mergeCells(`G${r12.number}:I${r12.number}`);
  r12.eachCell((cell) => { cell.border = borderThin; });
  r12.getCell(1).alignment = { wrapText: true, vertical: "top" };
  r12.height = 70; // Extra height for description

  let r13 = ws.addRow(["", "", "", "", "", "", data?.personnelList?.[2] || "", "", ""]);
  ws.mergeCells(`E${r13.number}:F${r13.number}`); ws.mergeCells(`G${r13.number}:I${r13.number}`);
  r13.eachCell((cell) => { cell.border = borderThin; });

  let r14 = ws.addRow(["", "", "", "", "", "", data?.personnelList?.[3] || "", "", ""]);
  ws.mergeCells(`E${r14.number}:F${r14.number}`); ws.mergeCells(`G${r14.number}:I${r14.number}`);
  r14.eachCell((cell) => { cell.border = borderThin; });

  // Dynamically merge description box vertically to avoid strict coordinate overlap errors
  ws.mergeCells(`A${r12.number}:D${r14.number}`); 

  let r15 = ws.addRow(["Source of Fund", data?.projectInfo?.fund || "20% 2025 EDF", "", "", "", "", "", "", ""]);
  ws.mergeCells(`B${r15.number}:I${r15.number}`);
  r15.eachCell((cell) => { cell.border = borderThin; });
  r15.getCell(1).font = { bold: true }; r15.getCell(2).font = { bold: true };

  // 5. Scope of Works Headers
  const th = ws.addRow([
    "ITEM",
    "Scope of Works ( Direct Cost )",
    "% Wt.",
    "QTY.",
    "UNIT",
    "UNIT COST",
    "TOTAL",
    "ADJUSTED COST",
    ""
  ]);
  ws.mergeCells(`H${th.number}:I${th.number}`);
  th.height = 30;
  th.font = { bold: true, size: 9 };
  th.alignment = { horizontal: "center", vertical: "middle", wrapText: true };
  th.fill = fillLightGray;
  th.eachCell((cell) => { cell.border = borderThin; });

  // 6. Scope of Works Items
  (data?.scopeItems || []).forEach((item) => {
    const qty = parseFloat(item.qty) || 0;
    const unitCost = parseFloat(item.unitCost) || 0;
    const itemTotal = qty * unitCost;
    const pctWt = dCost > 0 ? (itemTotal / dCost) : 0;

    let r = ws.addRow([item.itemNo || "", item.desc || "", pctWt, qty, item.unit || "", unitCost, itemTotal, "", ""]);
    ws.mergeCells(`H${r.number}:I${r.number}`);
    r.eachCell((cell) => { cell.border = borderThin; });

    r.getCell(2).alignment = { wrapText: true };
    r.getCell(3).numFmt = "0.00%";
    r.getCell(3).alignment = { horizontal: "center" };
    r.getCell(4).alignment = { horizontal: "center" };
    r.getCell(5).alignment = { horizontal: "center" };
    r.getCell(6).numFmt = "#,##0.00";
    r.getCell(7).numFmt = "#,##0.00";
    r.getCell(7).font = { bold: true };
  });

  // Total Direct Cost Bar (Yellow)
  let tdcRow = ws.addRow(["", "Total Direct Cost", 1, "", "", "", dCost, "", ""]);
  ws.mergeCells(`D${tdcRow.number}:F${tdcRow.number}`);
  ws.mergeCells(`H${tdcRow.number}:I${tdcRow.number}`);
  tdcRow.font = { bold: true };
  tdcRow.fill = fillYellow;
  tdcRow.eachCell((cell) => { cell.border = borderThin; });
  tdcRow.getCell(3).numFmt = "0.00%";
  tdcRow.getCell(3).alignment = { horizontal: "center" };
  tdcRow.getCell(7).numFmt = "#,##0.00";

  ws.addRow([]); // Blank spacer

  // 7. Breakdown of Cost Area
  let br1 = ws.addRow(["Breakdown of Estimated Project Cost", "", "Total \nConstruction \nCost", "Source of Fund", "", "", "", "", "TOTAL"]);
  let br2 = ws.addRow(["", "", "", "BLGU", "", "MLGU", "", "NAT'L FUNDS", ""]);
  let br3 = ws.addRow(["", "", "", "In kind", "Cash", "In kind", "Cash", "", ""]);

  ws.mergeCells(`A${br1.number}:B${br3.number}`);
  ws.mergeCells(`C${br1.number}:C${br3.number}`);
  ws.mergeCells(`D${br1.number}:H${br1.number}`);
  ws.mergeCells(`D${br2.number}:E${br2.number}`);
  ws.mergeCells(`F${br2.number}:G${br2.number}`);
  ws.mergeCells(`H${br2.number}:H${br3.number}`);
  ws.mergeCells(`I${br1.number}:I${br3.number}`);

  [br1, br2, br3].forEach((row) => {
    row.font = { bold: true, size: 9 };
    row.alignment = { horizontal: "center", vertical: "middle", wrapText: true };
    row.eachCell((cell) => { cell.border = borderThin; });
  });

  // Helper for fast Breakdown Rows
  const addBdRow = (label, value, isBold = false, fill = null) => {
    let r = ws.addRow([label, "", value, "", "", "", "", value, value]);
    ws.mergeCells(`A${r.number}:B${r.number}`);
    r.eachCell((cell) => { cell.border = borderThin; });
    r.getCell(3).numFmt = "#,##0.00";
    r.getCell(8).numFmt = "#,##0.00";
    r.getCell(9).numFmt = "#,##0.00";
    if (isBold) r.font = { bold: true };
    if (fill) r.fill = fill;
    return r;
  };

  let rDir = ws.addRow(["A. Direct Cost", "", "", "", "", "", "", "", ""]);
  ws.mergeCells(`A${rDir.number}:B${rDir.number}`);
  rDir.font = { bold: true };
  rDir.eachCell((cell) => { cell.border = borderThin; });

  addBdRow("  Materials", materials);
  addBdRow("  Labor", labor);
  addBdRow("  Equipment", equipment);
  addBdRow("  Hauling", hauling);
  addBdRow("TOTAL DIRECT COST", dCost, true, fillYellow);

  let rIndir = ws.addRow(["B. Indirect Cost", "", "", "", "", "", "", "", ""]);
  ws.mergeCells(`A${rIndir.number}:B${rIndir.number}`);
  rIndir.font = { bold: true };
  rIndir.eachCell((cell) => { cell.border = borderThin; });

  addBdRow(`  Contingencies & Miscellaneous (${contPct}%)`, contingencies);
  addBdRow(`  Contractor Profit (${profPct}%)`, profit);
  addBdRow(`  Taxes (Direct + Indirect Cost) x ${taxPct}%`, taxes);

  const indirectTotal = contingencies + profit + taxes;
  addBdRow("TOTAL OF INDIRECT COST", indirectTotal, true, fillYellow);
  addBdRow("TOTAL BUDGET OF THE CONTRACT", totalContract, true, fillYellow);

  let rOver = ws.addRow(["Overhead Expenses:", "", "", "", "", "", "", "", ""]);
  ws.mergeCells(`A${rOver.number}:B${rOver.number}`);
  rOver.font = { bold: true };
  rOver.eachCell((cell) => { cell.border = borderThin; });

  addBdRow(`  Engineering Supervision (${supPct}%)`, engSup);
  addBdRow("TOTAL PROJECT COST", totalProjectCost, true, fillGreen);

  let rShare = ws.addRow(["% Cost Sharing", "", 1, "", "", "", "", 1, 1]);
  ws.mergeCells(`A${rShare.number}:B${rShare.number}`);
  rShare.eachCell((cell) => { cell.border = borderThin; });
  rShare.font = { bold: true };
  rShare.getCell(1).alignment = { horizontal: "center" };
  rShare.getCell(3).numFmt = "0.00%";
  rShare.getCell(8).numFmt = "0.00%";
  rShare.getCell(9).numFmt = "0.00%";

  ws.addRow([]); // Blank spacer
  ws.addRow([]); // Blank spacer

  // 8. Signatories
  let sigRow1 = ws.addRow(["", "Prepared by:", "", "", "", "Checked by:", "", "", ""]);
  let sigRow2 = ws.addRow(["", data?.signatories?.prepName || "NOEL G. ABIS", "", "", "", data?.signatories?.checkName || "RONALD E. CABRALES", "", "", ""]);
  let sigRow3 = ws.addRow(["", data?.signatories?.prepTitle || "C.E. Aide", "", "", "", data?.signatories?.checkTitle || "Carpentry Foreman", "", "", ""]);

  [sigRow1, sigRow2, sigRow3].forEach((r) => {
    ws.mergeCells(`B${r.number}:D${r.number}`);
    ws.mergeCells(`F${r.number}:H${r.number}`);
  });
  sigRow2.font = { bold: true };
  sigRow2.getCell(2).alignment = { horizontal: "center" };
  sigRow2.getCell(6).alignment = { horizontal: "center" };
  sigRow3.getCell(2).alignment = { horizontal: "center" };
  sigRow3.getCell(6).alignment = { horizontal: "center" };

  ws.addRow([]);
  let sigRow4 = ws.addRow(["", "Reviewed by:", "", "", "", "As Priority Project:", "", "", ""]);
  let sigRow5 = ws.addRow(["", data?.signatories?.revName || "ENGR. ERWIN D. LIGUTOM", "", "", "", data?.signatories?.prioName || "VANESSA T. ALCUIZAR, EnP", "", "", ""]);
  let sigRow6 = ws.addRow(["", data?.signatories?.revTitle || "Engineer II", "", "", "", data?.signatories?.prioTitle || "Municipal Engineer", "", "", ""]);

  [sigRow4, sigRow5, sigRow6].forEach((r) => {
    ws.mergeCells(`B${r.number}:D${r.number}`);
    ws.mergeCells(`F${r.number}:H${r.number}`);
  });
  sigRow5.font = { bold: true };
  sigRow5.getCell(2).alignment = { horizontal: "center" };
  sigRow5.getCell(6).alignment = { horizontal: "center" };
  sigRow6.getCell(2).alignment = { horizontal: "center" };
  sigRow6.getCell(6).alignment = { horizontal: "center" };

  ws.addRow([]);
  let sigRow7 = ws.addRow(["", "Recommending For Approval:", "", "", "", "Approved by:", "", "", ""]);
  let sigRow8 = ws.addRow(["", data?.signatories?.recName || "ENGR. JOSELITO A. ELICAN", "", "", "", data?.signatories?.appName || "HON. MACARIO V. TINGSON", "", "", ""]);
  let sigRow9 = ws.addRow(["", data?.signatories?.recTitle || "Municipal Engineer", "", "", "", data?.signatories?.appTitle || "Municipal Mayor", "", "", ""]);

  [sigRow7, sigRow8, sigRow9].forEach((r) => {
    ws.mergeCells(`B${r.number}:D${r.number}`);
    ws.mergeCells(`F${r.number}:H${r.number}`);
  });
  sigRow8.font = { bold: true };
  sigRow8.getCell(2).alignment = { horizontal: "center" };
  sigRow8.getCell(6).alignment = { horizontal: "center" };
  sigRow9.getCell(2).alignment = { horizontal: "center" };
  sigRow9.getCell(6).alignment = { horizontal: "center" };

  // 9. Save and Download the file
  try {
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    const title = data?.projectInfo?.title || "POW";
    const date = new Date().toISOString().split("T")[0];
    const sanitized = title.replace(/[^a-z0-9]/gi, "_").substring(0, 50);
    window.saveAs(blob, `${sanitized}_${date}.xlsx`);
  } catch (err) {
    console.error("Error generating Excel file:", err);
    alert("There was an error exporting the Excel file.");
  }
}